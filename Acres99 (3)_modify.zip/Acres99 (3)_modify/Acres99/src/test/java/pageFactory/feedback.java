package pageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class feedback {
	WebDriver driver;
	public feedback(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
		
	}
	@FindBy(xpath="//*[@id='side_widget_feedback']/span")
	WebElement feedback;
	@FindBy(xpath="//input[@name='Email']")
	WebElement emails;
	@FindBy(xpath="//textarea[text()='My idea for this page is....']")
	WebElement textdata;
	@FindBy(xpath="//*[@id='side_widget_wrapper']/div[2]/div[2]/div[2]/form/div[4]/span/input")
	WebElement send;
	
	
	public void Feedback() {
		feedback.click();
	}
	public void data(String email,String text) {
		emails.sendKeys(email);
		textdata.sendKeys(text);
	}
	public void Email(String e) {
		emails.sendKeys(e);
	}
	public void Text(String t) {
		textdata.sendKeys(t);
}
	public void Send() {
		send.click();
	}
	
}
