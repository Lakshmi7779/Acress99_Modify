package pageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class nonLocality {
	WebDriver driver;
	public nonLocality(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	@FindBy(xpath="//*[@id='keyword']")
	WebElement EnterLocality;
	@FindBy(xpath="//*[@id=\"lvl5_form\"]/div[2]/div[2]/div[2]/button[1]/span")
	WebElement search;
	
	public void Enterlocality(String nonlocal) {	
		EnterLocality.sendKeys(nonlocal);
	}
	public void Search() {
		search.click();
	}
	
}
