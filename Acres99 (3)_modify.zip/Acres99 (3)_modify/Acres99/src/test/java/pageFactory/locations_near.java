package pageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class locations_near {

	WebDriver driver;
public locations_near(WebDriver driver) {
	this.driver=driver;
	PageFactory.initElements(driver,this);
	
}
@FindBy(xpath="//div[@class='pageComponent component__nearme']")
WebElement near;

public void Near() {
	near.click();
}

}
