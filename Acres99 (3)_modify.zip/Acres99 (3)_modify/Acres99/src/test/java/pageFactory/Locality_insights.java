package pageFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;



public class Locality_insights {
	WebDriver driver;
	WebDriverWait wait;
	public Locality_insights(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	@FindBy(xpath="/html/body/div[1]/div/div[2]/div[2]/div[2]/div[1]/div[5]")
	WebElement insights;
	@FindBy(xpath="//a[@title='Hyderabad  Overview' and @class='pageComponent']")
	WebElement hyderabad;
	@FindBy(xpath="//i[@class='iconS_Common_24 icon_share']")
	WebElement share;

	public void insights()  {
		Actions actions=new Actions(driver);
		actions.moveToElement(insights).perform();
		
	}
	public void Localityinsights() {
		hyderabad.click();
	}
	
public void share() {
	share.click();
}

	
}
