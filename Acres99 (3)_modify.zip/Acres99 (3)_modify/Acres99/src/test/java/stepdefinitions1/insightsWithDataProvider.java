package stepdefinitions1;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageFactory.ExcelData;
import pageFactory.Locality_insights;
import pageFactory.feedback;
import pageFactory.locations_near;
import pageFactory.nonLocality;

public class insightsWithDataProvider {
	WebDriver driver;
	@DataProvider(name="testdata")
	public Object getData() {
		ExcelData utils=new ExcelData("C:\\Users\\MDOLALAK\\eclipse-workspace\\Acres99\\src\\test\\resources\\EXCELDATA.xlsx");
		int rows=utils.getRowCount(0);
		Object[][] feedback=new Object[rows][2];
		for(int i=0;i<rows;i++) {
			for(int j=0;j<2;j++) {
				feedback[i][j]=utils.getdata(0,i+1, j);
				System.out.println(feedback[i][j]);
			}
		}
		return feedback;
				
	}
	@BeforeMethod public void before1() {
		driver=new EdgeDriver();
		driver.get("https://www.99acres.com/");
        driver.manage().window().maximize();
        Locality_insights li=new Locality_insights(driver);
		li.insights();
		li.Localityinsights();
		String c="";
		Set<String> child_handles= driver.getWindowHandles();
		for(String child:child_handles ) {
			c=child;
		}
		driver.switchTo().window(c);
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	   locations_near ln= new locations_near(driver);
		ln.Near();
	}
	@Test(dataProvider="testdata")
	public void details(String email,String text) {
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		feedback f= new feedback(driver);
		f.Feedback();
		f.data(email,text);
		f.Send();

	}
}
