package stepdefinitions1;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;

import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageFactory.Locality_insights;
import pageFactory.feedback;
import pageFactory.locations_near;
import pageFactory.nonLocality;

public class insights {

	static WebDriver driver;
	String ExpectedURL = "https://www.99acres.com/";
	
	@Before
	public void before(){
		driver=new EdgeDriver();
        driver.manage().window().maximize();
	}

	@Given("I open the web browser")
	public void i_open_the_web_browser() {
		driver.get("https://www.99acres.com/");
        driver.manage().window().maximize();
	}

	@When("I navigates to the application URL")
	public void i_navigates_to_the_application_url() {
		driver.get("https://www.99acres.com/");
	}

	@Then("I should see the Home Page")
//	public void i_should_see_the_home_page() {
//		String url=driver.getCurrentUrl();
//        System.out.println(url);
//		Assert.assertEquals(url,ExpectedURL);
//		
//	}

	@When("see the Home Page")
	public void see_the_home_page() { 
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		
	}

	@When("I click on insights")
	public void i_click_on_insights() {
		Locality_insights li=new Locality_insights(driver);
		li.insights();
	}

	@When("I click on Hyderabad Overview")
	public void i_click_on_hyderabad_overview() {
		Locality_insights li=new Locality_insights(driver);
		li.Localityinsights();
		}

	@Then("I navigates to Hyderabad Overview page successfully")
	public void i_navigates_to_hyderabad_overview_page_successfully() {
//		boolean hyderabadOverviewDisplayed=driver.findElement(By.xpath("//div[text()='India Real Estate Property Site - Buy Sell Rent Properties Portal - 99acres.com']")).isDisplayed();
//		Assert.assertTrue(hyderabadOverviewDisplayed);
		
	}

	@When("I  see the Home Page")
	public void i_see_the_home_page() {
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
	}

	@When("I click on share")
	public void i_click_on_share() {
		String c="";
		Set<String> child_handles= driver.getWindowHandles();
		for(String child:child_handles ) {
			c=child;
		}
		driver.switchTo().window(c);
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		Locality_insights li=new Locality_insights(driver);
		li.share();
	}

	@Then("it show a popup")
	public void it_show_a_popup() { 
		System.out.println("Popup showed");
	}
	
	@When("I enter non locality as {string}")
	public void i_enter_non_locality_as(String nonlocal) {
		String c="";
		Set<String> child_handles= driver.getWindowHandles();
		for(String child:child_handles ) {
			c=child;
		}
		driver.switchTo().window(c);
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	   nonLocality x=new nonLocality(driver);
	   x.Enterlocality(nonlocal);
	}

	@When("I enter Search")
	public void i_enter_search() {
		String c="";
		Set<String> child_handles= driver.getWindowHandles();
		for(String child:child_handles ) {
			c=child;
		}
		driver.switchTo().window(c);
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	   nonLocality x=new nonLocality(driver);
	   x.Search();
	    
	}

	@Then("It will throw a message as {string}")
	public void it_will_throw_a_message_as(String string) {
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);  
	}

	@When("I click on the near me locations")
	public void i_click_on_the_near_me_locations() {
		String c="";
		Set<String> child_handles= driver.getWindowHandles();
		for(String child:child_handles ) {
			c=child;
		}
		driver.switchTo().window(c);
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		locations_near ln= new locations_near(driver);
		ln.Near();
	}
	@When("I allow the location access")
	public void i_allow_the_location_access() {
//		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
//		JavascriptExecutor js = (JavascriptExecutor)driver;
//        js.executeScript("window.scrollTo(0,400)");
		
	}
	@Then("I will be able to see the locations of Hyderabad")
	public void i_will_be_able_to_see_the_locations_of_hyderabad() {
//		boolean isHyderabadLocationsVisible=isElementPresent(By.xpath("//div[@class='pageComponent component__nearme']"));
//		Assert.assertTrue(isHyderabadLocationsVisible);
	}
//	private boolean isElementPresent(By locator) {
//		try {
//			driver.findElement(locator);
//			return true;
//		}catch(NoSuchElementException e) {
//			return false;
//		}
//	}
	@When("I click on Feedback")
	public void i_click_on_feedback() {
		feedback f= new feedback(driver);
		f.Feedback();
	}

	@When("I enter email as {string}")
	public void i_enter_email_as(String email) {
		feedback f= new feedback(driver);
		f.Email(email);
	}

	@When("I enter feedback as {string}")
	public void i_enter_feedback_as(String text) {
		feedback f= new feedback(driver);
		f.Text(text);
	}
	@When("I click on send")
	public void i_click_on_send() {
		feedback f= new feedback(driver);
		f.Send();
	}

	@Then("feedback is sent successfully")
	public void feedback_is_sent_successfully() { 
	}
//	@AfterStep
//	public static void tearDown(Scenario scenario){
// 
//   final byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
//   scenario.attach(screenshot, "image/png", scenario.getName());
//}
}
