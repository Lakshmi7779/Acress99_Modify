import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {
	private WebDriver driver;
	private By user=By.name("username");
	private By pass=By.name("password");
	private By login=By.xpath("//button[@type='submit']");
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
	}
	public void setUsername(String userName) {
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

		WebElement a1=driver.findElement(user);
		a1.sendKeys(userName);
	}
	public void setPassword(String password) {
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

		driver.findElement(pass).sendKeys(password);
	}
	public void click() {
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

		driver.findElement(login).click();
	}
	public void login(String userName, String password) {
		setUsername(userName);
		setPassword(password);
		click();
	}
}
